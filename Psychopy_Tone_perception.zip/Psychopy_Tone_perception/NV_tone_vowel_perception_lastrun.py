﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2026.1.3),
    on Fri Jun 19 04:53:46 2026
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, hardware
from psychopy.tools import environmenttools
from psychopy.constants import (
    NOT_STARTED, STARTED, PLAYING, PAUSED, STOPPED, STOPPING, FINISHED, PRESSED, 
    RELEASED, FOREVER, priority
)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard

# Run 'Before Experiment' code from code_position
# setting position for images and texts
place_i1=(-0.4, 0)
place_i2=(0.4, 0)

place_w1=(-0.4, -0.3)
place_w2=(0.4, -0.3)

place_k1=(-0.4, -0.4)
place_k2=(0.4, -0.4)
# --- Setup global variables (available in all functions) ---
# create a device manager to handle hardware (keyboards, mice, mirophones, speakers, etc.)
deviceManager = hardware.DeviceManager()
# ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# store info about the experiment session
psychopyVersion = '2026.1.3'
expName = 'tone_and_vowel_oddball'  # from the Builder filename that created this script
expVersion = ''
# a list of functions to run when the experiment ends (starts off blank)
runAtExit = []
# information about this experiment
expInfo = {
    'participant': '',
    'session': '001',
    'date|hid': data.getDateStr(),
    'expName|hid': expName,
    'expVersion|hid': expVersion,
    'psychopyVersion|hid': psychopyVersion,
}

# --- Define some variables which will change depending on pilot mode ---
'''
To run in pilot mode, either use the run/pilot toggle in Builder, Coder and Runner, 
or run the experiment with `--pilot` as an argument. To change what pilot 
#mode does, check out the 'Pilot mode' tab in preferences.
'''
# work out from system args whether we are running in pilot mode
PILOTING = core.setPilotModeFromArgs()
# start off with values from experiment settings
_fullScr = True
_winSize = [1280, 720]
# if in pilot mode, apply overrides according to preferences
if PILOTING:
    # force windowed mode
    if prefs.piloting['forceWindowed']:
        _fullScr = False
        # set window size
        _winSize = prefs.piloting['forcedWindowSize']
    # replace default participant ID
    if prefs.piloting['replaceParticipantID']:
        expInfo['participant'] = 'pilot'

def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # show participant info dialog
    dlg = gui.DlgFromDict(
        dictionary=expInfo, sortKeys=False, title=expName, alwaysOnTop=True
    )
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    # remove dialog-specific syntax from expInfo
    for key, val in expInfo.copy().items():
        newKey, _ = data.utils.parsePipeSyntax(key)
        expInfo[newKey] = expInfo.pop(key)
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version=expVersion,
        extraInfo=expInfo, runtimeInfo=None,
        originPath='/Users/xiewenda/Desktop/Psychopy_Tone_perception/NV_tone_vowel_perception_lastrun.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    # store pilot mode in data file
    thisExp.addData('piloting', PILOTING, priority=priority.LOW)
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # set how much information should be printed to the console / app
    if PILOTING:
        logging.console.setLevel(
            prefs.piloting['pilotConsoleLoggingLevel']
        )
    else:
        logging.console.setLevel('warning')
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log')
    if PILOTING:
        logFile.setLevel(
            prefs.piloting['pilotLoggingLevel']
        )
    else:
        logFile.setLevel(
            logging.getLevel('warning')
        )
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if PILOTING:
        logging.debug('Fullscreen settings ignored as running in pilot mode.')
    
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=_winSize, fullscr=_fullScr, screen=0,
            winType='pyglet', allowGUI=False, allowStencil=True,
            monitor='testMonitor', color=[1,1,1], colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='height',
            checkTiming=False  # we're going to do this ourselves in a moment
        )
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = [1,1,1]
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'height'
    if expInfo is not None:
        # get/measure frame rate if not already in expInfo
        if win._monitorFrameRate is None:
            win._monitorFrameRate = win.getActualFrameRate(infoMsg='Attempting to measure frame rate of screen, please wait...')
        expInfo['frameRate'] = win._monitorFrameRate
    win.hideMessage()
    if PILOTING:
        # show a visual indicator if we're in piloting mode
        if prefs.piloting['showPilotingIndicator']:
            win.showPilotingIndicator()
        # always show the mouse in piloting mode
        if prefs.piloting['forceMouseVisible']:
            win.mouseVisible = True
    
    return win


def setupDevices(expInfo, thisExp, win):
    """
    Setup whatever devices are available (mouse, keyboard, speaker, eyetracker, etc.) and add them to 
    the device manager (deviceManager)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    bool
        True if completed successfully.
    """
    # --- Setup input devices ---
    ioConfig = {}
    ioSession = ioServer = eyetracker = None
    
    # store ioServer object in the device manager
    deviceManager.ioServer = ioServer
    
    # create a default keyboard (e.g. to check for escape)
    if deviceManager.getDevice('defaultKeyboard') is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='ptb'
        )
    # return True if completed successfully
    return True

def pauseExperiment(thisExp, win=None, timers=[], currentRoutine=None):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    currentRoutine : psychopy.data.Routine
        Current Routine we are in at time of pausing, if any. This object tells PsychoPy what Components to pause/play/dispatch.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # start a timer to figure out how long we're paused for
    pauseTimer = core.Clock()
    # pause any playback components
    if currentRoutine is not None:
        for comp in currentRoutine.getPlaybackComponents():
            comp.pause()
    # make sure we have a keyboard
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        defaultKeyboard = deviceManager.addKeyboard(
            deviceClass='keyboard',
            deviceName='defaultKeyboard',
            backend='PsychToolbox',
        )
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win)
        # dispatch messages on response components
        if currentRoutine is not None:
            for comp in currentRoutine.getDispatchComponents():
                comp.device.dispatchMessages()
        # sleep 1ms so other threads can execute
        clock.time.sleep(0.001)
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, win=win)
    # resume any playback components
    if currentRoutine is not None:
        for comp in currentRoutine.getPlaybackComponents():
            comp.play()
    # reset any timers
    for timer in timers:
        timer.addTime(-pauseTimer.getTime())


def run(expInfo, thisExp, win, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # update experiment info
    expInfo['date'] = data.getDateStr()
    expInfo['expName'] = expName
    expInfo['expVersion'] = expVersion
    expInfo['psychopyVersion'] = psychopyVersion
    # make sure window is set to foreground to prevent losing focus
    win.winHandle.activate()
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = deviceManager.ioServer
    # get/create a default keyboard (e.g. to check for escape)
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='PsychToolbox'
        )
    eyetracker = deviceManager.getDevice('eyetracker')
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    
    # --- Initialize components for Routine "welcome" ---
    text_welcome = visual.TextStim(win=win, name='text_welcome',
        text='Welcome to the experiment\n\nPress SPACEBAR to start.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='black', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_welcome = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "practice_instruction" ---
    text_practice_instruction = visual.TextBox2(
         win, text='We are about to start the practice section. Please read the following instruction carefully before starting:\n\nYou will see two pictures along with their corresponding words, and hear a sound twice.\n\nIf the sound corresponds to the picture/word on the left, press Q.\n\nIf the sound corresponds to the picture/word on the right, press P.\n\nPress SPACEBAR to continue when you are ready.', placeholder='Type here...', font='Arial',
         ori=0.0, pos=(0, 0), draggable=False,      letterHeight=0.05,
         size=(1.5, 1), borderWidth=2.0,
         color='black', colorSpace='rgb',
         opacity=None,
         bold=False, italic=False,
         lineSpacing=1.0, speechPoint=None,
         padding=0.0, alignment='center',
         anchor='center', overflow='visible',
         fillColor=None, borderColor=None,
         flipHoriz=False, flipVert=False, languageStyle='LTR',
         editable=False,
         name='text_practice_instruction',
         depth=0, autoLog=True,
    )
    key_practice_instruction = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "practice" ---
    fixation_practice = visual.ShapeStim(
        win=win, name='fixation_practice', vertices='cross',
        size=(0.05, 0.05),
        ori=0.0, pos=(0, 0), draggable=False, anchor='center',
        lineWidth=1.0,
        colorSpace='rgb', lineColor='black', fillColor='black',
        opacity=None, depth=0.0, interpolate=True)
    image1_prac = visual.ImageStim(
        win=win,
        name='image1_prac', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=[0,0], draggable=False, size=(0.5, 0.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-2.0)
    image2_prac = visual.ImageStim(
        win=win,
        name='image2_prac', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=[0,0], draggable=False, size=(0.5, 0.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-3.0)
    word1_prac = visual.TextStim(win=win, name='word1_prac',
        text='',
        font='Arial',
        pos=[0,0], draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='black', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    word2_prac = visual.TextStim(win=win, name='word2_prac',
        text='',
        font='Arial',
        pos=[0,0], draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='black', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-5.0);
    resp1_prac = visual.TextStim(win=win, name='resp1_prac',
        text='',
        font='Arial',
        pos=[0,0], draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='black', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-6.0);
    resp2_prac = visual.TextStim(win=win, name='resp2_prac',
        text='',
        font='Arial',
        pos=[0,0], draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='black', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-7.0);
    response_prac = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "practice_fb" ---
    fb_prac = visual.TextStim(win=win, name='fb_prac',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "trial_instruction" ---
    text_changeBlock = visual.TextBox2(
         win, text='We are about to start the experiment. Please read the following instruction carefully before starting:\n\nYou will see two pictures along with their corresponding words, and hear a sound twice.\n\nIf the sound corresponds to the picture/word on the left, press Q.\n\nIf the sound corresponds to the picture/word on the right, press P.\n\nPress SPACEBAR to continue when you are ready.', placeholder='Type here...', font='Arial',
         ori=0.0, pos=(0, 0), draggable=False,      letterHeight=0.05,
         size=(1.5, 1), borderWidth=2.0,
         color='black', colorSpace='rgb',
         opacity=None,
         bold=False, italic=False,
         lineSpacing=1.0, speechPoint=None,
         padding=0.0, alignment='center',
         anchor='center', overflow='visible',
         fillColor=None, borderColor=None,
         flipHoriz=False, flipVert=False, languageStyle='LTR',
         editable=False,
         name='text_changeBlock',
         depth=0, autoLog=True,
    )
    key_changeBlock = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "trial" ---
    fixation = visual.ShapeStim(
        win=win, name='fixation', vertices='cross',
        size=(0.05, 0.05),
        ori=0.0, pos=(0, 0), draggable=False, anchor='center',
        lineWidth=1.0,
        colorSpace='rgb', lineColor='black', fillColor='black',
        opacity=None, depth=0.0, interpolate=True)
    image1 = visual.ImageStim(
        win=win,
        name='image1', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=[0,0], draggable=False, size=(0.5, 0.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-2.0)
    image2 = visual.ImageStim(
        win=win,
        name='image2', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=[0,0], draggable=False, size=(0.5, 0.5),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-3.0)
    word1 = visual.TextStim(win=win, name='word1',
        text='',
        font='Arial',
        pos=[0,0], draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='black', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    word2 = visual.TextStim(win=win, name='word2',
        text='',
        font='Arial',
        pos=[0,0], draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='black', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-5.0);
    resp1 = visual.TextStim(win=win, name='resp1',
        text='',
        font='Arial',
        pos=[0,0], draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='black', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-6.0);
    resp2 = visual.TextStim(win=win, name='resp2',
        text='',
        font='Arial',
        pos=[0,0], draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='black', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-7.0);
    response = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "pause" ---
    text_break = visual.TextBox2(
         win, text='You now have a 1-minute break, press SPACEBAR to continue when you are ready.', placeholder='Type here...', font='Arial',
         ori=0.0, pos=(0, 0), draggable=False,      letterHeight=0.05,
         size=(1, 1), borderWidth=2.0,
         color='black', colorSpace='rgb',
         opacity=None,
         bold=False, italic=False,
         lineSpacing=1.0, speechPoint=None,
         padding=0.0, alignment='center',
         anchor='center', overflow='visible',
         fillColor=None, borderColor=None,
         flipHoriz=False, flipVert=False, languageStyle='LTR',
         editable=False,
         name='text_break',
         depth=-1, autoLog=True,
    )
    key_break = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "ending" ---
    text_ending = visual.TextStim(win=win, name='text_ending',
        text='Thank you for participating!',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='black', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_ending = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # create some handy timers
    
    # global clock to track the time since experiment started
    if globalClock is None:
        # create a clock if not given one
        globalClock = core.Clock()
    if isinstance(globalClock, str):
        # if given a string, make a clock accoridng to it
        if globalClock == 'float':
            # get timestamps as a simple value
            globalClock = core.Clock(format='float')
        elif globalClock == 'iso':
            # get timestamps in ISO format
            globalClock = core.Clock(format='%Y-%m-%d_%H:%M:%S.%f%z')
        else:
            # get timestamps in a custom format
            globalClock = core.Clock(format=globalClock)
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    if eyetracker is not None:
        eyetracker.enableEventReporting()
    # routine timer to track time remaining of each (possibly non-slip) routine
    routineTimer = core.Clock()
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(
        format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6
    )
    
    # --- Prepare to start Routine "welcome" ---
    # create an object to store info about Routine welcome
    welcome = data.Routine(
        name='welcome',
        components=[text_welcome, key_welcome],
    )
    welcome.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_welcome
    key_welcome.keys = []
    key_welcome.rt = []
    _key_welcome_allKeys = []
    # store start times for welcome
    welcome.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    welcome.tStart = globalClock.getTime(format='float')
    welcome.status = STARTED
    thisExp.addData('welcome.started', welcome.tStart)
    welcome.maxDuration = None
    # keep track of which components have finished
    welcomeComponents = welcome.components
    for thisComponent in welcome.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "welcome" ---
    thisExp.currentRoutine = welcome
    welcome.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_welcome* updates
        
        # if text_welcome is starting this frame...
        if text_welcome.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_welcome.frameNStart = frameN  # exact frame index
            text_welcome.tStart = t  # local t and not account for scr refresh
            text_welcome.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_welcome, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_welcome.started')
            # update status
            text_welcome.status = STARTED
            text_welcome.setAutoDraw(True)
        
        # if text_welcome is active this frame...
        if text_welcome.status == STARTED:
            # update params
            pass
        
        # *key_welcome* updates
        waitOnFlip = False
        
        # if key_welcome is starting this frame...
        if key_welcome.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_welcome.frameNStart = frameN  # exact frame index
            key_welcome.tStart = t  # local t and not account for scr refresh
            key_welcome.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_welcome, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_welcome.started')
            # update status
            key_welcome.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_welcome.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_welcome.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_welcome.status == STARTED and not waitOnFlip:
            theseKeys = key_welcome.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_welcome_allKeys.extend(theseKeys)
            if len(_key_welcome_allKeys):
                key_welcome.keys = _key_welcome_allKeys[-1].name  # just the last key pressed
                key_welcome.rt = _key_welcome_allKeys[-1].rt
                key_welcome.duration = _key_welcome_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=welcome,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            welcome.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if welcome.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in welcome.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "welcome" ---
    for thisComponent in welcome.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for welcome
    welcome.tStop = globalClock.getTime(format='float')
    welcome.tStopRefresh = tThisFlipGlobal
    thisExp.addData('welcome.stopped', welcome.tStop)
    # check responses
    if key_welcome.keys in ['', [], None]:  # No response was made
        key_welcome.keys = None
    thisExp.addData('key_welcome.keys',key_welcome.keys)
    if key_welcome.keys != None:  # we had a response
        thisExp.addData('key_welcome.rt', key_welcome.rt)
        thisExp.addData('key_welcome.duration', key_welcome.duration)
    thisExp.nextEntry()
    # the Routine "welcome" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "practice_instruction" ---
    # create an object to store info about Routine practice_instruction
    practice_instruction = data.Routine(
        name='practice_instruction',
        components=[text_practice_instruction, key_practice_instruction],
    )
    practice_instruction.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    text_practice_instruction.reset()
    # create starting attributes for key_practice_instruction
    key_practice_instruction.keys = []
    key_practice_instruction.rt = []
    _key_practice_instruction_allKeys = []
    # store start times for practice_instruction
    practice_instruction.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    practice_instruction.tStart = globalClock.getTime(format='float')
    practice_instruction.status = STARTED
    thisExp.addData('practice_instruction.started', practice_instruction.tStart)
    practice_instruction.maxDuration = None
    # keep track of which components have finished
    practice_instructionComponents = practice_instruction.components
    for thisComponent in practice_instruction.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "practice_instruction" ---
    thisExp.currentRoutine = practice_instruction
    practice_instruction.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_practice_instruction* updates
        
        # if text_practice_instruction is starting this frame...
        if text_practice_instruction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_practice_instruction.frameNStart = frameN  # exact frame index
            text_practice_instruction.tStart = t  # local t and not account for scr refresh
            text_practice_instruction.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_practice_instruction, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_practice_instruction.started')
            # update status
            text_practice_instruction.status = STARTED
            text_practice_instruction.setAutoDraw(True)
        
        # if text_practice_instruction is active this frame...
        if text_practice_instruction.status == STARTED:
            # update params
            pass
        
        # *key_practice_instruction* updates
        waitOnFlip = False
        
        # if key_practice_instruction is starting this frame...
        if key_practice_instruction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_practice_instruction.frameNStart = frameN  # exact frame index
            key_practice_instruction.tStart = t  # local t and not account for scr refresh
            key_practice_instruction.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_practice_instruction, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_practice_instruction.started')
            # update status
            key_practice_instruction.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_practice_instruction.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_practice_instruction.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_practice_instruction.status == STARTED and not waitOnFlip:
            theseKeys = key_practice_instruction.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_practice_instruction_allKeys.extend(theseKeys)
            if len(_key_practice_instruction_allKeys):
                key_practice_instruction.keys = _key_practice_instruction_allKeys[-1].name  # just the last key pressed
                key_practice_instruction.rt = _key_practice_instruction_allKeys[-1].rt
                key_practice_instruction.duration = _key_practice_instruction_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=practice_instruction,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            practice_instruction.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if practice_instruction.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in practice_instruction.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "practice_instruction" ---
    for thisComponent in practice_instruction.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for practice_instruction
    practice_instruction.tStop = globalClock.getTime(format='float')
    practice_instruction.tStopRefresh = tThisFlipGlobal
    thisExp.addData('practice_instruction.stopped', practice_instruction.tStop)
    # check responses
    if key_practice_instruction.keys in ['', [], None]:  # No response was made
        key_practice_instruction.keys = None
    thisExp.addData('key_practice_instruction.keys',key_practice_instruction.keys)
    if key_practice_instruction.keys != None:  # we had a response
        thisExp.addData('key_practice_instruction.rt', key_practice_instruction.rt)
        thisExp.addData('key_practice_instruction.duration', key_practice_instruction.duration)
    thisExp.nextEntry()
    # the Routine "practice_instruction" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials_practice = data.TrialHandler2(
        name='trials_practice',
        nReps=1, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('block_prac.xlsx'), 
        seed=1, 
        isTrials=True, 
    )
    thisExp.addLoop(trials_practice)  # add the loop to the experiment
    thisTrials_practice = trials_practice.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrials_practice.rgb)
    if thisTrials_practice != None:
        for paramName in thisTrials_practice:
            globals()[paramName] = thisTrials_practice[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisTrials_practice in trials_practice:
        trials_practice.status = STARTED
        if hasattr(thisTrials_practice, 'status'):
            thisTrials_practice.status = STARTED
        currentLoop = trials_practice
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisTrials_practice.rgb)
        if thisTrials_practice != None:
            for paramName in thisTrials_practice:
                globals()[paramName] = thisTrials_practice[paramName]
        
        # --- Prepare to start Routine "practice" ---
        # create an object to store info about Routine practice
        practice = data.Routine(
            name='practice',
            components=[fixation_practice, image1_prac, image2_prac, word1_prac, word2_prac, resp1_prac, resp2_prac, response_prac],
        )
        practice.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from code_prac
        # reset trạng thái phản hồi
        thisExp.addData('sound_played', False)
        
        # tạo sound object từ variable stimuli
        sound_tone = sound.Sound(stimuli, secs=-1)
        sound_tone.setVolume(1.0)
        
        # disable response lúc đầu
        response_prac.status = NOT_STARTED
        allowed_keys = ""
        
        # Khởi tạo biến trạng thái
        practice.phase = 0
        practice.t0 = globalClock.getTime()
        image1_prac.setPos(place_i1)
        image1_prac.setImage(picture1)
        image2_prac.setPos(place_i2)
        image2_prac.setImage(picture2)
        word1_prac.setPos(place_w1)
        word1_prac.setText(text1)
        word2_prac.setPos(place_w2)
        word2_prac.setText(text2)
        resp1_prac.setPos(place_k1)
        resp1_prac.setText(key1)
        resp2_prac.setPos(place_k2)
        resp2_prac.setText(key2)
        # create starting attributes for response_prac
        response_prac.keys = []
        response_prac.rt = []
        _response_prac_allKeys = []
        # allowedKeys looks like a variable, so make sure it exists locally
        if 'allowed_keys' in globals():
            allowed_keys = globals()['allowed_keys']
        # store start times for practice
        practice.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        practice.tStart = globalClock.getTime(format='float')
        practice.status = STARTED
        thisExp.addData('practice.started', practice.tStart)
        practice.maxDuration = None
        # keep track of which components have finished
        practiceComponents = practice.components
        for thisComponent in practice.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "practice" ---
        thisExp.currentRoutine = practice
        practice.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 6.0:
            # if trial has changed, end Routine now
            if hasattr(thisTrials_practice, 'status') and thisTrials_practice.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *fixation_practice* updates
            
            # if fixation_practice is starting this frame...
            if fixation_practice.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                fixation_practice.frameNStart = frameN  # exact frame index
                fixation_practice.tStart = t  # local t and not account for scr refresh
                fixation_practice.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(fixation_practice, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'fixation_practice.started')
                # update status
                fixation_practice.status = STARTED
                fixation_practice.setAutoDraw(True)
            
            # if fixation_practice is active this frame...
            if fixation_practice.status == STARTED:
                # update params
                pass
            
            # if fixation_practice is stopping this frame...
            if fixation_practice.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > fixation_practice.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    fixation_practice.tStop = t  # not accounting for scr refresh
                    fixation_practice.tStopRefresh = tThisFlipGlobal  # on global time
                    fixation_practice.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'fixation_practice.stopped')
                    # update status
                    fixation_practice.status = FINISHED
                    fixation_practice.setAutoDraw(False)
            # Run 'Each Frame' code from code_prac
            t = globalClock.getTime()
            # Phase 1: chờ 0.5s rồi play lần 1
            if practice.phase == 0:
                if t - practice.t0 >= 0.5:
                    sound_tone.play()
                    practice.phase = 1
                    practice.t1 = t
            
            # Phase 2: đợi sound chạy xong + pause 0.5s
            # lần 2 xong → cho response
            elif practice.phase == 1:
                if t - practice.t1 >= (sound_tone.getDuration() + 0.5):
                    sound_tone.play()
                    practice.phase = 2
            
            # Phase 3: sau khi play lần 2 xong → cho response
            elif practice.phase == 2:
                if t - practice.t1 >= (sound_tone.getDuration()*2 + 0.5):
                    # enable response
                    response_prac.status = STARTED
                    allowed_keys='q','p'
                    continueRoutine = True
            
            # *image1_prac* updates
            
            # if image1_prac is starting this frame...
            if image1_prac.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                image1_prac.frameNStart = frameN  # exact frame index
                image1_prac.tStart = t  # local t and not account for scr refresh
                image1_prac.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image1_prac, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image1_prac.started')
                # update status
                image1_prac.status = STARTED
                image1_prac.setAutoDraw(True)
            
            # if image1_prac is active this frame...
            if image1_prac.status == STARTED:
                # update params
                pass
            
            # if image1_prac is stopping this frame...
            if image1_prac.status == STARTED:
                # is it time to stop? (based on local clock)
                if tThisFlip > 6-frameTolerance:
                    # keep track of stop time/frame for later
                    image1_prac.tStop = t  # not accounting for scr refresh
                    image1_prac.tStopRefresh = tThisFlipGlobal  # on global time
                    image1_prac.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image1_prac.stopped')
                    # update status
                    image1_prac.status = FINISHED
                    image1_prac.setAutoDraw(False)
            
            # *image2_prac* updates
            
            # if image2_prac is starting this frame...
            if image2_prac.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                image2_prac.frameNStart = frameN  # exact frame index
                image2_prac.tStart = t  # local t and not account for scr refresh
                image2_prac.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image2_prac, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image2_prac.started')
                # update status
                image2_prac.status = STARTED
                image2_prac.setAutoDraw(True)
            
            # if image2_prac is active this frame...
            if image2_prac.status == STARTED:
                # update params
                pass
            
            # if image2_prac is stopping this frame...
            if image2_prac.status == STARTED:
                # is it time to stop? (based on local clock)
                if tThisFlip > 6-frameTolerance:
                    # keep track of stop time/frame for later
                    image2_prac.tStop = t  # not accounting for scr refresh
                    image2_prac.tStopRefresh = tThisFlipGlobal  # on global time
                    image2_prac.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image2_prac.stopped')
                    # update status
                    image2_prac.status = FINISHED
                    image2_prac.setAutoDraw(False)
            
            # *word1_prac* updates
            
            # if word1_prac is starting this frame...
            if word1_prac.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                word1_prac.frameNStart = frameN  # exact frame index
                word1_prac.tStart = t  # local t and not account for scr refresh
                word1_prac.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(word1_prac, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'word1_prac.started')
                # update status
                word1_prac.status = STARTED
                word1_prac.setAutoDraw(True)
            
            # if word1_prac is active this frame...
            if word1_prac.status == STARTED:
                # update params
                pass
            
            # if word1_prac is stopping this frame...
            if word1_prac.status == STARTED:
                # is it time to stop? (based on local clock)
                if tThisFlip > 6-frameTolerance:
                    # keep track of stop time/frame for later
                    word1_prac.tStop = t  # not accounting for scr refresh
                    word1_prac.tStopRefresh = tThisFlipGlobal  # on global time
                    word1_prac.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'word1_prac.stopped')
                    # update status
                    word1_prac.status = FINISHED
                    word1_prac.setAutoDraw(False)
            
            # *word2_prac* updates
            
            # if word2_prac is starting this frame...
            if word2_prac.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                word2_prac.frameNStart = frameN  # exact frame index
                word2_prac.tStart = t  # local t and not account for scr refresh
                word2_prac.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(word2_prac, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'word2_prac.started')
                # update status
                word2_prac.status = STARTED
                word2_prac.setAutoDraw(True)
            
            # if word2_prac is active this frame...
            if word2_prac.status == STARTED:
                # update params
                pass
            
            # if word2_prac is stopping this frame...
            if word2_prac.status == STARTED:
                # is it time to stop? (based on local clock)
                if tThisFlip > 6-frameTolerance:
                    # keep track of stop time/frame for later
                    word2_prac.tStop = t  # not accounting for scr refresh
                    word2_prac.tStopRefresh = tThisFlipGlobal  # on global time
                    word2_prac.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'word2_prac.stopped')
                    # update status
                    word2_prac.status = FINISHED
                    word2_prac.setAutoDraw(False)
            
            # *resp1_prac* updates
            
            # if resp1_prac is starting this frame...
            if resp1_prac.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                resp1_prac.frameNStart = frameN  # exact frame index
                resp1_prac.tStart = t  # local t and not account for scr refresh
                resp1_prac.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(resp1_prac, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'resp1_prac.started')
                # update status
                resp1_prac.status = STARTED
                resp1_prac.setAutoDraw(True)
            
            # if resp1_prac is active this frame...
            if resp1_prac.status == STARTED:
                # update params
                pass
            
            # if resp1_prac is stopping this frame...
            if resp1_prac.status == STARTED:
                # is it time to stop? (based on local clock)
                if tThisFlip > 6-frameTolerance:
                    # keep track of stop time/frame for later
                    resp1_prac.tStop = t  # not accounting for scr refresh
                    resp1_prac.tStopRefresh = tThisFlipGlobal  # on global time
                    resp1_prac.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'resp1_prac.stopped')
                    # update status
                    resp1_prac.status = FINISHED
                    resp1_prac.setAutoDraw(False)
            
            # *resp2_prac* updates
            
            # if resp2_prac is starting this frame...
            if resp2_prac.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                resp2_prac.frameNStart = frameN  # exact frame index
                resp2_prac.tStart = t  # local t and not account for scr refresh
                resp2_prac.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(resp2_prac, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'resp2_prac.started')
                # update status
                resp2_prac.status = STARTED
                resp2_prac.setAutoDraw(True)
            
            # if resp2_prac is active this frame...
            if resp2_prac.status == STARTED:
                # update params
                pass
            
            # if resp2_prac is stopping this frame...
            if resp2_prac.status == STARTED:
                # is it time to stop? (based on local clock)
                if tThisFlip > 6-frameTolerance:
                    # keep track of stop time/frame for later
                    resp2_prac.tStop = t  # not accounting for scr refresh
                    resp2_prac.tStopRefresh = tThisFlipGlobal  # on global time
                    resp2_prac.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'resp2_prac.stopped')
                    # update status
                    resp2_prac.status = FINISHED
                    resp2_prac.setAutoDraw(False)
            
            # *response_prac* updates
            waitOnFlip = False
            
            # if response_prac is starting this frame...
            if response_prac.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                response_prac.frameNStart = frameN  # exact frame index
                response_prac.tStart = t  # local t and not account for scr refresh
                response_prac.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(response_prac, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'response_prac.started')
                # update status
                response_prac.status = STARTED
                # allowed keys looks like a variable named `allowed_keys`
                if not type(allowed_keys) in [list, tuple, np.ndarray]:
                    if not isinstance(allowed_keys, str):
                        allowed_keys = str(allowed_keys)
                    elif not ',' in allowed_keys:
                        allowed_keys = (allowed_keys,)
                    else:
                        allowed_keys = eval(allowed_keys)
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(response_prac.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(response_prac.clearEvents, eventType='keyboard')  # clear events on next screen flip
            
            # if response_prac is stopping this frame...
            if response_prac.status == STARTED:
                # is it time to stop? (based on local clock)
                if tThisFlip > 6-frameTolerance:
                    # keep track of stop time/frame for later
                    response_prac.tStop = t  # not accounting for scr refresh
                    response_prac.tStopRefresh = tThisFlipGlobal  # on global time
                    response_prac.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'response_prac.stopped')
                    # update status
                    response_prac.status = FINISHED
                    response_prac.status = FINISHED
            if response_prac.status == STARTED and not waitOnFlip:
                theseKeys = response_prac.getKeys(keyList=list(allowed_keys), ignoreKeys=["escape"], waitRelease=False)
                _response_prac_allKeys.extend(theseKeys)
                if len(_response_prac_allKeys):
                    response_prac.keys = _response_prac_allKeys[-1].name  # just the last key pressed
                    response_prac.rt = _response_prac_allKeys[-1].rt
                    response_prac.duration = _response_prac_allKeys[-1].duration
                    # was this correct?
                    if (response_prac.keys == str(corr_ans)) or (response_prac.keys == corr_ans):
                        response_prac.corr = 1
                    else:
                        response_prac.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=practice,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                practice.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if practice.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in practice.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "practice" ---
        for thisComponent in practice.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for practice
        practice.tStop = globalClock.getTime(format='float')
        practice.tStopRefresh = tThisFlipGlobal
        thisExp.addData('practice.stopped', practice.tStop)
        # Run 'End Routine' code from code_prac
        allowed_keys = ""
        # check responses
        if response_prac.keys in ['', [], None]:  # No response was made
            response_prac.keys = None
            # was no response the correct answer?!
            if str(corr_ans).lower() == 'none':
               response_prac.corr = 1;  # correct non-response
            else:
               response_prac.corr = 0;  # failed to respond (incorrectly)
        # store data for trials_practice (TrialHandler)
        trials_practice.addData('response_prac.keys',response_prac.keys)
        trials_practice.addData('response_prac.corr', response_prac.corr)
        if response_prac.keys != None:  # we had a response
            trials_practice.addData('response_prac.rt', response_prac.rt)
            trials_practice.addData('response_prac.duration', response_prac.duration)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if practice.maxDurationReached:
            routineTimer.addTime(-practice.maxDuration)
        elif practice.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-6.000000)
        
        # --- Prepare to start Routine "practice_fb" ---
        # create an object to store info about Routine practice_fb
        practice_fb = data.Routine(
            name='practice_fb',
            components=[fb_prac],
        )
        practice_fb.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from fb_code
        if response_prac.corr == 1:
            fb_text = "Correct!"
            fb_color="green"
        else:
            fb_text = "Incorrect!"
            fb_color="red"
        fb_prac.setColor(fb_color, colorSpace='rgb')
        fb_prac.setText(fb_text)
        # store start times for practice_fb
        practice_fb.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        practice_fb.tStart = globalClock.getTime(format='float')
        practice_fb.status = STARTED
        thisExp.addData('practice_fb.started', practice_fb.tStart)
        practice_fb.maxDuration = None
        # keep track of which components have finished
        practice_fbComponents = practice_fb.components
        for thisComponent in practice_fb.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "practice_fb" ---
        thisExp.currentRoutine = practice_fb
        practice_fb.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 0.5:
            # if trial has changed, end Routine now
            if hasattr(thisTrials_practice, 'status') and thisTrials_practice.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *fb_prac* updates
            
            # if fb_prac is starting this frame...
            if fb_prac.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                fb_prac.frameNStart = frameN  # exact frame index
                fb_prac.tStart = t  # local t and not account for scr refresh
                fb_prac.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(fb_prac, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'fb_prac.started')
                # update status
                fb_prac.status = STARTED
                fb_prac.setAutoDraw(True)
            
            # if fb_prac is active this frame...
            if fb_prac.status == STARTED:
                # update params
                pass
            
            # if fb_prac is stopping this frame...
            if fb_prac.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > fb_prac.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    fb_prac.tStop = t  # not accounting for scr refresh
                    fb_prac.tStopRefresh = tThisFlipGlobal  # on global time
                    fb_prac.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'fb_prac.stopped')
                    # update status
                    fb_prac.status = FINISHED
                    fb_prac.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=practice_fb,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                practice_fb.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if practice_fb.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in practice_fb.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "practice_fb" ---
        for thisComponent in practice_fb.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for practice_fb
        practice_fb.tStop = globalClock.getTime(format='float')
        practice_fb.tStopRefresh = tThisFlipGlobal
        thisExp.addData('practice_fb.stopped', practice_fb.tStop)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if practice_fb.maxDurationReached:
            routineTimer.addTime(-practice_fb.maxDuration)
        elif practice_fb.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-0.500000)
        # mark thisTrials_practice as finished
        if hasattr(thisTrials_practice, 'status'):
            thisTrials_practice.status = FINISHED
        # if awaiting a pause, pause now
        if trials_practice.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            trials_practice.status = STARTED
        thisExp.nextEntry()
        
    # completed 1 repeats of 'trials_practice'
    trials_practice.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "trial_instruction" ---
    # create an object to store info about Routine trial_instruction
    trial_instruction = data.Routine(
        name='trial_instruction',
        components=[text_changeBlock, key_changeBlock],
    )
    trial_instruction.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    text_changeBlock.reset()
    # create starting attributes for key_changeBlock
    key_changeBlock.keys = []
    key_changeBlock.rt = []
    _key_changeBlock_allKeys = []
    # store start times for trial_instruction
    trial_instruction.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    trial_instruction.tStart = globalClock.getTime(format='float')
    trial_instruction.status = STARTED
    thisExp.addData('trial_instruction.started', trial_instruction.tStart)
    trial_instruction.maxDuration = None
    # keep track of which components have finished
    trial_instructionComponents = trial_instruction.components
    for thisComponent in trial_instruction.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "trial_instruction" ---
    thisExp.currentRoutine = trial_instruction
    trial_instruction.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_changeBlock* updates
        
        # if text_changeBlock is starting this frame...
        if text_changeBlock.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_changeBlock.frameNStart = frameN  # exact frame index
            text_changeBlock.tStart = t  # local t and not account for scr refresh
            text_changeBlock.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_changeBlock, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_changeBlock.started')
            # update status
            text_changeBlock.status = STARTED
            text_changeBlock.setAutoDraw(True)
        
        # if text_changeBlock is active this frame...
        if text_changeBlock.status == STARTED:
            # update params
            pass
        
        # *key_changeBlock* updates
        waitOnFlip = False
        
        # if key_changeBlock is starting this frame...
        if key_changeBlock.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_changeBlock.frameNStart = frameN  # exact frame index
            key_changeBlock.tStart = t  # local t and not account for scr refresh
            key_changeBlock.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_changeBlock, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_changeBlock.started')
            # update status
            key_changeBlock.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_changeBlock.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_changeBlock.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_changeBlock.status == STARTED and not waitOnFlip:
            theseKeys = key_changeBlock.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_changeBlock_allKeys.extend(theseKeys)
            if len(_key_changeBlock_allKeys):
                key_changeBlock.keys = _key_changeBlock_allKeys[-1].name  # just the last key pressed
                key_changeBlock.rt = _key_changeBlock_allKeys[-1].rt
                key_changeBlock.duration = _key_changeBlock_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=trial_instruction,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            trial_instruction.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if trial_instruction.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in trial_instruction.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "trial_instruction" ---
    for thisComponent in trial_instruction.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for trial_instruction
    trial_instruction.tStop = globalClock.getTime(format='float')
    trial_instruction.tStopRefresh = tThisFlipGlobal
    thisExp.addData('trial_instruction.stopped', trial_instruction.tStop)
    # check responses
    if key_changeBlock.keys in ['', [], None]:  # No response was made
        key_changeBlock.keys = None
    thisExp.addData('key_changeBlock.keys',key_changeBlock.keys)
    if key_changeBlock.keys != None:  # we had a response
        thisExp.addData('key_changeBlock.rt', key_changeBlock.rt)
        thisExp.addData('key_changeBlock.duration', key_changeBlock.duration)
    thisExp.nextEntry()
    # the Routine "trial_instruction" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials_loop = data.TrialHandler2(
        name='trials_loop',
        nReps=2.0, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('block_trial.xlsx'), 
        seed=1, 
        isTrials=True, 
    )
    thisExp.addLoop(trials_loop)  # add the loop to the experiment
    thisTrials_loop = trials_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrials_loop.rgb)
    if thisTrials_loop != None:
        for paramName in thisTrials_loop:
            globals()[paramName] = thisTrials_loop[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisTrials_loop in trials_loop:
        trials_loop.status = STARTED
        if hasattr(thisTrials_loop, 'status'):
            thisTrials_loop.status = STARTED
        currentLoop = trials_loop
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisTrials_loop.rgb)
        if thisTrials_loop != None:
            for paramName in thisTrials_loop:
                globals()[paramName] = thisTrials_loop[paramName]
        
        # --- Prepare to start Routine "trial" ---
        # create an object to store info about Routine trial
        trial = data.Routine(
            name='trial',
            components=[fixation, image1, image2, word1, word2, resp1, resp2, response],
        )
        trial.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from code_trial
        # reset trạng thái phản hồi
        thisExp.addData('sound_played', False)
        
        # tạo sound object từ variable stimuli
        sound_tone = sound.Sound(stimuli, secs=-1)
        sound_tone.setVolume(1.0)
        
        # disable response lúc đầu
        response.status = NOT_STARTED
        allowed_keys = ""
        
        # Khởi tạo biến trạng thái
        trial.phase = 0
        trial.t0 = globalClock.getTime()
        image1.setPos(place_i1)
        image1.setImage(picture1)
        image2.setPos(place_i2)
        image2.setImage(picture2)
        word1.setPos(place_w1)
        word1.setText(text1)
        word2.setPos(place_w2)
        word2.setText(text2)
        resp1.setPos(place_k1)
        resp1.setText(key1)
        resp2.setPos(place_k2)
        resp2.setText(key2)
        # create starting attributes for response
        response.keys = []
        response.rt = []
        _response_allKeys = []
        # allowedKeys looks like a variable, so make sure it exists locally
        if 'allowed_keys' in globals():
            allowed_keys = globals()['allowed_keys']
        # store start times for trial
        trial.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        trial.tStart = globalClock.getTime(format='float')
        trial.status = STARTED
        thisExp.addData('trial.started', trial.tStart)
        trial.maxDuration = None
        # keep track of which components have finished
        trialComponents = trial.components
        for thisComponent in trial.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "trial" ---
        thisExp.currentRoutine = trial
        trial.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 6.0:
            # if trial has changed, end Routine now
            if hasattr(thisTrials_loop, 'status') and thisTrials_loop.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *fixation* updates
            
            # if fixation is starting this frame...
            if fixation.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                fixation.frameNStart = frameN  # exact frame index
                fixation.tStart = t  # local t and not account for scr refresh
                fixation.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(fixation, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'fixation.started')
                # update status
                fixation.status = STARTED
                fixation.setAutoDraw(True)
            
            # if fixation is active this frame...
            if fixation.status == STARTED:
                # update params
                pass
            
            # if fixation is stopping this frame...
            if fixation.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > fixation.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    fixation.tStop = t  # not accounting for scr refresh
                    fixation.tStopRefresh = tThisFlipGlobal  # on global time
                    fixation.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'fixation.stopped')
                    # update status
                    fixation.status = FINISHED
                    fixation.setAutoDraw(False)
            # Run 'Each Frame' code from code_trial
            t = globalClock.getTime()
            # Phase 1: chờ 0.5s rồi play lần 1
            if trial.phase == 0:
                if t - trial.t0 >= 0.5:
                    sound_tone.play()
                    trial.phase = 1
                    trial.t1 = t
            
            # Phase 2: đợi sound chạy xong + pause 0.5s
            # lần 2 xong → cho response
            elif trial.phase == 1:
                if t - trial.t1 >= (sound_tone.getDuration() + 0.5):
                    sound_tone.play()
                    trial.phase = 2
            
            # Phase 3: sau khi play lần 2 xong → cho response
            elif trial.phase == 2:
                if t - trial.t1 >= (sound_tone.getDuration()*2 + 0.5):
                    # enable response
                    response.status = STARTED
                    allowed_keys='q','p'
                    continueRoutine = True
            
            # *image1* updates
            
            # if image1 is starting this frame...
            if image1.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                image1.frameNStart = frameN  # exact frame index
                image1.tStart = t  # local t and not account for scr refresh
                image1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image1, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image1.started')
                # update status
                image1.status = STARTED
                image1.setAutoDraw(True)
            
            # if image1 is active this frame...
            if image1.status == STARTED:
                # update params
                pass
            
            # if image1 is stopping this frame...
            if image1.status == STARTED:
                # is it time to stop? (based on local clock)
                if tThisFlip > 6-frameTolerance:
                    # keep track of stop time/frame for later
                    image1.tStop = t  # not accounting for scr refresh
                    image1.tStopRefresh = tThisFlipGlobal  # on global time
                    image1.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image1.stopped')
                    # update status
                    image1.status = FINISHED
                    image1.setAutoDraw(False)
            
            # *image2* updates
            
            # if image2 is starting this frame...
            if image2.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                image2.frameNStart = frameN  # exact frame index
                image2.tStart = t  # local t and not account for scr refresh
                image2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image2, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image2.started')
                # update status
                image2.status = STARTED
                image2.setAutoDraw(True)
            
            # if image2 is active this frame...
            if image2.status == STARTED:
                # update params
                pass
            
            # if image2 is stopping this frame...
            if image2.status == STARTED:
                # is it time to stop? (based on local clock)
                if tThisFlip > 6-frameTolerance:
                    # keep track of stop time/frame for later
                    image2.tStop = t  # not accounting for scr refresh
                    image2.tStopRefresh = tThisFlipGlobal  # on global time
                    image2.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image2.stopped')
                    # update status
                    image2.status = FINISHED
                    image2.setAutoDraw(False)
            
            # *word1* updates
            
            # if word1 is starting this frame...
            if word1.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                word1.frameNStart = frameN  # exact frame index
                word1.tStart = t  # local t and not account for scr refresh
                word1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(word1, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'word1.started')
                # update status
                word1.status = STARTED
                word1.setAutoDraw(True)
            
            # if word1 is active this frame...
            if word1.status == STARTED:
                # update params
                pass
            
            # if word1 is stopping this frame...
            if word1.status == STARTED:
                # is it time to stop? (based on local clock)
                if tThisFlip > 6-frameTolerance:
                    # keep track of stop time/frame for later
                    word1.tStop = t  # not accounting for scr refresh
                    word1.tStopRefresh = tThisFlipGlobal  # on global time
                    word1.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'word1.stopped')
                    # update status
                    word1.status = FINISHED
                    word1.setAutoDraw(False)
            
            # *word2* updates
            
            # if word2 is starting this frame...
            if word2.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                word2.frameNStart = frameN  # exact frame index
                word2.tStart = t  # local t and not account for scr refresh
                word2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(word2, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'word2.started')
                # update status
                word2.status = STARTED
                word2.setAutoDraw(True)
            
            # if word2 is active this frame...
            if word2.status == STARTED:
                # update params
                pass
            
            # if word2 is stopping this frame...
            if word2.status == STARTED:
                # is it time to stop? (based on local clock)
                if tThisFlip > 6-frameTolerance:
                    # keep track of stop time/frame for later
                    word2.tStop = t  # not accounting for scr refresh
                    word2.tStopRefresh = tThisFlipGlobal  # on global time
                    word2.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'word2.stopped')
                    # update status
                    word2.status = FINISHED
                    word2.setAutoDraw(False)
            
            # *resp1* updates
            
            # if resp1 is starting this frame...
            if resp1.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                resp1.frameNStart = frameN  # exact frame index
                resp1.tStart = t  # local t and not account for scr refresh
                resp1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(resp1, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'resp1.started')
                # update status
                resp1.status = STARTED
                resp1.setAutoDraw(True)
            
            # if resp1 is active this frame...
            if resp1.status == STARTED:
                # update params
                pass
            
            # if resp1 is stopping this frame...
            if resp1.status == STARTED:
                # is it time to stop? (based on local clock)
                if tThisFlip > 6-frameTolerance:
                    # keep track of stop time/frame for later
                    resp1.tStop = t  # not accounting for scr refresh
                    resp1.tStopRefresh = tThisFlipGlobal  # on global time
                    resp1.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'resp1.stopped')
                    # update status
                    resp1.status = FINISHED
                    resp1.setAutoDraw(False)
            
            # *resp2* updates
            
            # if resp2 is starting this frame...
            if resp2.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                resp2.frameNStart = frameN  # exact frame index
                resp2.tStart = t  # local t and not account for scr refresh
                resp2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(resp2, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'resp2.started')
                # update status
                resp2.status = STARTED
                resp2.setAutoDraw(True)
            
            # if resp2 is active this frame...
            if resp2.status == STARTED:
                # update params
                pass
            
            # if resp2 is stopping this frame...
            if resp2.status == STARTED:
                # is it time to stop? (based on local clock)
                if tThisFlip > 6-frameTolerance:
                    # keep track of stop time/frame for later
                    resp2.tStop = t  # not accounting for scr refresh
                    resp2.tStopRefresh = tThisFlipGlobal  # on global time
                    resp2.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'resp2.stopped')
                    # update status
                    resp2.status = FINISHED
                    resp2.setAutoDraw(False)
            
            # *response* updates
            waitOnFlip = False
            
            # if response is starting this frame...
            if response.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                response.frameNStart = frameN  # exact frame index
                response.tStart = t  # local t and not account for scr refresh
                response.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(response, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'response.started')
                # update status
                response.status = STARTED
                # allowed keys looks like a variable named `allowed_keys`
                if not type(allowed_keys) in [list, tuple, np.ndarray]:
                    if not isinstance(allowed_keys, str):
                        allowed_keys = str(allowed_keys)
                    elif not ',' in allowed_keys:
                        allowed_keys = (allowed_keys,)
                    else:
                        allowed_keys = eval(allowed_keys)
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(response.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(response.clearEvents, eventType='keyboard')  # clear events on next screen flip
            
            # if response is stopping this frame...
            if response.status == STARTED:
                # is it time to stop? (based on local clock)
                if tThisFlip > 6-frameTolerance:
                    # keep track of stop time/frame for later
                    response.tStop = t  # not accounting for scr refresh
                    response.tStopRefresh = tThisFlipGlobal  # on global time
                    response.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'response.stopped')
                    # update status
                    response.status = FINISHED
                    response.status = FINISHED
            if response.status == STARTED and not waitOnFlip:
                theseKeys = response.getKeys(keyList=list(allowed_keys), ignoreKeys=["escape"], waitRelease=False)
                _response_allKeys.extend(theseKeys)
                if len(_response_allKeys):
                    response.keys = _response_allKeys[-1].name  # just the last key pressed
                    response.rt = _response_allKeys[-1].rt
                    response.duration = _response_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=trial,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                trial.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if trial.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in trial.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "trial" ---
        for thisComponent in trial.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for trial
        trial.tStop = globalClock.getTime(format='float')
        trial.tStopRefresh = tThisFlipGlobal
        thisExp.addData('trial.stopped', trial.tStop)
        # Run 'End Routine' code from code_trial
        allowed_keys = ""
        # check responses
        if response.keys in ['', [], None]:  # No response was made
            response.keys = None
        trials_loop.addData('response.keys',response.keys)
        if response.keys != None:  # we had a response
            trials_loop.addData('response.rt', response.rt)
            trials_loop.addData('response.duration', response.duration)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if trial.maxDurationReached:
            routineTimer.addTime(-trial.maxDuration)
        elif trial.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-6.000000)
        
        # --- Prepare to start Routine "pause" ---
        # create an object to store info about Routine pause
        pause = data.Routine(
            name='pause',
            components=[text_break, key_break],
        )
        pause.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from code_break
        #break every 30 trials (after a 30-trial loop)
        if trials_loop.thisN > 0 and trials_loop.thisN % 30 == 0:
            continueRoutine = True
        else:
            continueRoutine = False
        text_break.reset()
        # create starting attributes for key_break
        key_break.keys = []
        key_break.rt = []
        _key_break_allKeys = []
        # store start times for pause
        pause.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        pause.tStart = globalClock.getTime(format='float')
        pause.status = STARTED
        thisExp.addData('pause.started', pause.tStart)
        pause.maxDuration = None
        # keep track of which components have finished
        pauseComponents = pause.components
        for thisComponent in pause.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "pause" ---
        thisExp.currentRoutine = pause
        pause.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 60.0:
            # if trial has changed, end Routine now
            if hasattr(thisTrials_loop, 'status') and thisTrials_loop.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_break* updates
            
            # if text_break is starting this frame...
            if text_break.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_break.frameNStart = frameN  # exact frame index
                text_break.tStart = t  # local t and not account for scr refresh
                text_break.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_break, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_break.started')
                # update status
                text_break.status = STARTED
                text_break.setAutoDraw(True)
            
            # if text_break is active this frame...
            if text_break.status == STARTED:
                # update params
                pass
            
            # if text_break is stopping this frame...
            if text_break.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_break.tStartRefresh + 60-frameTolerance:
                    # keep track of stop time/frame for later
                    text_break.tStop = t  # not accounting for scr refresh
                    text_break.tStopRefresh = tThisFlipGlobal  # on global time
                    text_break.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_break.stopped')
                    # update status
                    text_break.status = FINISHED
                    text_break.setAutoDraw(False)
            
            # *key_break* updates
            waitOnFlip = False
            
            # if key_break is starting this frame...
            if key_break.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_break.frameNStart = frameN  # exact frame index
                key_break.tStart = t  # local t and not account for scr refresh
                key_break.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_break, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_break.started')
                # update status
                key_break.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_break.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_break.clearEvents, eventType='keyboard')  # clear events on next screen flip
            
            # if key_break is stopping this frame...
            if key_break.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > key_break.tStartRefresh + 60-frameTolerance:
                    # keep track of stop time/frame for later
                    key_break.tStop = t  # not accounting for scr refresh
                    key_break.tStopRefresh = tThisFlipGlobal  # on global time
                    key_break.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_break.stopped')
                    # update status
                    key_break.status = FINISHED
                    key_break.status = FINISHED
            if key_break.status == STARTED and not waitOnFlip:
                theseKeys = key_break.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _key_break_allKeys.extend(theseKeys)
                if len(_key_break_allKeys):
                    key_break.keys = _key_break_allKeys[-1].name  # just the last key pressed
                    key_break.rt = _key_break_allKeys[-1].rt
                    key_break.duration = _key_break_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=pause,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                pause.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if pause.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in pause.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "pause" ---
        for thisComponent in pause.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for pause
        pause.tStop = globalClock.getTime(format='float')
        pause.tStopRefresh = tThisFlipGlobal
        thisExp.addData('pause.stopped', pause.tStop)
        # check responses
        if key_break.keys in ['', [], None]:  # No response was made
            key_break.keys = None
        trials_loop.addData('key_break.keys',key_break.keys)
        if key_break.keys != None:  # we had a response
            trials_loop.addData('key_break.rt', key_break.rt)
            trials_loop.addData('key_break.duration', key_break.duration)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if pause.maxDurationReached:
            routineTimer.addTime(-pause.maxDuration)
        elif pause.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-60.000000)
        # mark thisTrials_loop as finished
        if hasattr(thisTrials_loop, 'status'):
            thisTrials_loop.status = FINISHED
        # if awaiting a pause, pause now
        if trials_loop.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            trials_loop.status = STARTED
        thisExp.nextEntry()
        
    # completed 2.0 repeats of 'trials_loop'
    trials_loop.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "ending" ---
    # create an object to store info about Routine ending
    ending = data.Routine(
        name='ending',
        components=[text_ending, key_ending],
    )
    ending.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_ending
    key_ending.keys = []
    key_ending.rt = []
    _key_ending_allKeys = []
    # store start times for ending
    ending.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    ending.tStart = globalClock.getTime(format='float')
    ending.status = STARTED
    thisExp.addData('ending.started', ending.tStart)
    ending.maxDuration = None
    # keep track of which components have finished
    endingComponents = ending.components
    for thisComponent in ending.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "ending" ---
    thisExp.currentRoutine = ending
    ending.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 20.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_ending* updates
        
        # if text_ending is starting this frame...
        if text_ending.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_ending.frameNStart = frameN  # exact frame index
            text_ending.tStart = t  # local t and not account for scr refresh
            text_ending.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_ending, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_ending.started')
            # update status
            text_ending.status = STARTED
            text_ending.setAutoDraw(True)
        
        # if text_ending is active this frame...
        if text_ending.status == STARTED:
            # update params
            pass
        
        # if text_ending is stopping this frame...
        if text_ending.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_ending.tStartRefresh + 20-frameTolerance:
                # keep track of stop time/frame for later
                text_ending.tStop = t  # not accounting for scr refresh
                text_ending.tStopRefresh = tThisFlipGlobal  # on global time
                text_ending.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_ending.stopped')
                # update status
                text_ending.status = FINISHED
                text_ending.setAutoDraw(False)
        
        # *key_ending* updates
        waitOnFlip = False
        
        # if key_ending is starting this frame...
        if key_ending.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_ending.frameNStart = frameN  # exact frame index
            key_ending.tStart = t  # local t and not account for scr refresh
            key_ending.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_ending, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_ending.started')
            # update status
            key_ending.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_ending.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_ending.clearEvents, eventType='keyboard')  # clear events on next screen flip
        
        # if key_ending is stopping this frame...
        if key_ending.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > key_ending.tStartRefresh + 20-frameTolerance:
                # keep track of stop time/frame for later
                key_ending.tStop = t  # not accounting for scr refresh
                key_ending.tStopRefresh = tThisFlipGlobal  # on global time
                key_ending.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_ending.stopped')
                # update status
                key_ending.status = FINISHED
                key_ending.status = FINISHED
        if key_ending.status == STARTED and not waitOnFlip:
            theseKeys = key_ending.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_ending_allKeys.extend(theseKeys)
            if len(_key_ending_allKeys):
                key_ending.keys = _key_ending_allKeys[-1].name  # just the last key pressed
                key_ending.rt = _key_ending_allKeys[-1].rt
                key_ending.duration = _key_ending_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=ending,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            ending.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if ending.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in ending.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "ending" ---
    for thisComponent in ending.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for ending
    ending.tStop = globalClock.getTime(format='float')
    ending.tStopRefresh = tThisFlipGlobal
    thisExp.addData('ending.stopped', ending.tStop)
    # check responses
    if key_ending.keys in ['', [], None]:  # No response was made
        key_ending.keys = None
    thisExp.addData('key_ending.keys',key_ending.keys)
    if key_ending.keys != None:  # we had a response
        thisExp.addData('key_ending.rt', key_ending.rt)
        thisExp.addData('key_ending.duration', key_ending.duration)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if ending.maxDurationReached:
        routineTimer.addTime(-ending.maxDuration)
    elif ending.forceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-20.000000)
    thisExp.nextEntry()
    
    # mark experiment as finished
    endExperiment(thisExp, win=win)


def saveData(thisExp):
    """
    Save data from this experiment
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    filename = thisExp.dataFileName
    # these shouldn't be strictly necessary (should auto-save)
    thisExp.saveAsWideText(filename + '.csv', delim='auto')
    thisExp.saveAsPickle(filename)


def endExperiment(thisExp, win=None):
    """
    End this experiment, performing final shut down operations.
    
    This function does NOT close the window or end the Python process - use `quit` for this.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    """
    # stop any playback components
    if thisExp.currentRoutine is not None:
        for comp in thisExp.currentRoutine.getPlaybackComponents():
            comp.stop()
    if win is not None:
        # remove autodraw from all current components
        win.clearAutoDraw()
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed
        win.flip()
    # return console logger level to WARNING
    logging.console.setLevel(logging.WARNING)
    # mark experiment handler as finished
    thisExp.status = FINISHED
    # run any 'at exit' functions
    for fcn in runAtExit:
        fcn()
    logging.flush()


def quit(thisExp, win=None, thisSession=None):
    """
    Fully quit, closing the window and ending the Python process.
    
    Parameters
    ==========
    win : psychopy.visual.Window
        Window to close.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    thisExp.abort()  # or data files will save again on exit
    # make sure everything is closed down
    if win is not None:
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed before quitting
        win.flip()
        win.close()
    logging.flush()
    if thisSession is not None:
        thisSession.stop()
    # terminate Python process
    core.quit()


# if running this experiment as a script...
if __name__ == '__main__':
    # call all functions in order
    expInfo = showExpInfoDlg(expInfo=expInfo)
    thisExp = setupData(expInfo=expInfo)
    logFile = setupLogging(filename=thisExp.dataFileName)
    win = setupWindow(expInfo=expInfo)
    setupDevices(expInfo=expInfo, thisExp=thisExp, win=win)
    run(
        expInfo=expInfo, 
        thisExp=thisExp, 
        win=win,
        globalClock='float'
    )
    saveData(thisExp=thisExp)
    quit(thisExp=thisExp, win=win)
